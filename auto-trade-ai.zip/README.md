# Auto Trade AI

자동매매 시스템 프로젝트입니다.

## 실행 방법
```bash
pip install -r requirements.txt
python ai_model.py
```