import webbrowser

# OneDrive 대용량 zip 링크
url = 'https://1drv.ms/f/c/da0220ddad3e6639/EuBJcDCW7bRAj4wnvL_uax0B_jWGud-knywwLEcf9LaNsg?e=hScikE'
webbrowser.open(url)
